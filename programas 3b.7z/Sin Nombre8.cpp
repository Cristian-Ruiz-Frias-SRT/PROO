#include <iostream>
#include <limits>

int main() {
    int valor = 10;
    int *ptr = &valor;

    if (ptr == NULL) {
        std::cout << "El puntero es nulo." << std::endl;
    } else {
        std::cout << "El valor apuntado por el puntero es: " << *ptr << std::endl;
        std::cout << "El valor m�ximo que puede almacenar un entero es: " 
                  << std::numeric_limits<int>::max() << std::endl;
    }

    return 0;
}

